Испольняемые файлы наъходятся в каталоге
Aviso\bin\Release\
Для работы необходимо иметь установленный MS Word не ниже 2007 версии и MS Access не ниже 2007 версии

Скриншоты находятся в папке Aviso\screen\

Для компиляции необходимо поставить:
- Visual Studio 2015 Community edition
- OpenXml SDK
https://www.microsoft.com/en-us/download/details.aspx?id=5124 (меньший из файлов)
- Черех NUGet поставить DocX


