﻿using System;
using System.Data.OleDb;

namespace Aviso
{


    partial class AvisoDataSet
    {
        partial class post_avisoDataTable
        {
        }
    }
}

namespace Aviso.AvisoDataSetTableAdapters
{
    partial class post_avisoTableAdapter
    {
        public static explicit operator OleDbDataAdapter(post_avisoTableAdapter v)
        {
            throw new NotImplementedException();
        }
    }

    public partial class telegraph_avisoTableAdapter {
    }
}
